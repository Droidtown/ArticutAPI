#!/usr/bin/env python3
# -*- coding:utf-8 -*-

"""
    Loki module for Exchange

    Input:
        pattern       str,
        args          str[],
        resultDICT    dict

    Output:
        resultDICT    dict
"""

DEBUG_Exchange = True

# 將符合句型的參數列表印出。這是 debug 或是開發用的。
def debugInfo(intent, args):
    if DEBUG_Exchange:
        print(intent, "===>", args)

def getResult(pattern, args, resultDICT):
    # [美金][100元]可以換多少[台幣]
    if pattern == "<ENTITY_UserDefined>[^<]*?</ENTITY_UserDefined><KNOWLEDGE_currency>[^<]*?</KNOWLEDGE_currency>(<MODAL>[^<]*?</MODAL>)?((<ACTION_verb>[^<不]*?[換][^<不]*?</ACTION_verb>)|(<VerbP>[^<不]*?[換][^<不]*?</VerbP>))<CLAUSE_HowQ>[^<]*?</CLAUSE_HowQ><ENTITY_UserDefined>[^<]*?</ENTITY_UserDefined>":
        debugInfo("[美金][100元]可以換多少[台幣]", args)
        # write your code here
        resultDICT = {"source":args[0],
                      "target":args[2],
                      "money":args[1]}

    # [100元][美金]要多少[台幣]
    if pattern == "<KNOWLEDGE_currency>[^<]*?</KNOWLEDGE_currency><ENTITY_UserDefined>[^<]*?</ENTITY_UserDefined>((<ACTION_verb>[^<不]*?[要][^<不]*?</ACTION_verb>)|(<VerbP>[^<不]*?[要][^<不]*?</VerbP>))<CLAUSE_HowQ>[^<]*?</CLAUSE_HowQ><ENTITY_UserDefined>[^<]*?</ENTITY_UserDefined>":
        debugInfo("[100元][美金]要多少[台幣]", args)
        # write your code here
        resultDICT = {"source":args[1],
                      "target":args[2],
                      "money":args[0]}
    # [100元][美金]可以換多少[台幣]
    if pattern == "<KNOWLEDGE_currency>[^<]*?</KNOWLEDGE_currency><ENTITY_UserDefined>[^<]*?</ENTITY_UserDefined>(<MODAL>[^<]*?</MODAL>)?((<ACTION_verb>[^<不]*?[換][^<不]*?</ACTION_verb>)|(<VerbP>[^<不]*?[換][^<不]*?</VerbP>))<CLAUSE_HowQ>[^<]*?</CLAUSE_HowQ><ENTITY_UserDefined>[^<]*?</ENTITY_UserDefined>":
        debugInfo("[100元][美金]可以換多少[台幣]", args)
        # write your code here
        resultDICT = {"source":args[1],
                      "target":args[2],
                      "money":args[0]}

    return resultDICT